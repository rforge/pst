pkgname <- "PST"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('PST')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("SRH-data")
### * SRH-data

flush(stderr()); flush(stdout())

### Name: SRH
### Title: Sequence data on self rated health from the Swiss household
###   panel
### Aliases: SRH
### Keywords: datasets

### ** Examples

data(SRH)
state.list <- levels(SRH$p99c01)
SRH.seq <- seqdef(SRH, 5:15, alphabet=state.list, states=c("G1", "G2", "M", "B2", "B1"), weights=SRH$wp09lp1s)



cleanEx()
nameEx("cplot")
### * cplot

flush(stderr()); flush(stdout())

### Name: cplot
### Title: Plot single nodes
### Aliases: cplot cplot,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)

cplot(S1, "a-b")



cleanEx()
nameEx("cprob")
### * cprob

flush(stderr()); flush(stdout())

### Name: cprob
### Title: Empirical conditional probability distributions of order 'L'
### Aliases: cprob cprob,stslist-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

	data(s1)
	s1 <- seqdef(s1)
	cprob(s1, L=0, prob=FALSE)
	cprob(s1, L=1, prob=TRUE)
	cprob(s1, L=1, prob=FALSE)
	cprob(s1, L=1, prob=TRUE)



cleanEx()
nameEx("generate")
### * generate

flush(stderr()); flush(stdout())

### Name: generate
### Title: Generate sequences using a PST
### Aliases: generate generate,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1.seq <- seqdef(s1)
S1 <- pstree(s1.seq, L=3)
generate(S1, n=10, l=10, method="prob")
## First state is generated with p(a)=0.9 and p(b)=0.1
generate(S1, n=10, l=10, method="prob", p1=c(0.9, 0.1))



cleanEx()
nameEx("impute")
### * impute

flush(stderr()); flush(stdout())

### Name: impute
### Title: Impute missing states in sequences using a Probabilistic Suffix
###   Tree
### Aliases: impute impute,PSTf,stslist-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)
predict(S1, s1, decomp=TRUE)
predict(S1, s1)



cleanEx()
nameEx("logLik")
### * logLik

flush(stderr()); flush(stdout())

### Name: logLik
### Title: Log Likelihood of a PST
### Aliases: logLik logLik,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1.seq <- seqdef(s1)
S1 <- pstree(s1.seq, L=3)
logLik(S1)	



cleanEx()
nameEx("nodenames")
### * nodenames

flush(stderr()); flush(stdout())

### Name: nodenames
### Title: Retrieve the node names of a PST
### Aliases: nodenames nodenames,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)

nodenames(S1, L=3)
nodenames(S1)



cleanEx()
nameEx("plot-PSTr")
### * plot-PSTr

flush(stderr()); flush(stdout())

### Name: plot-PSTr
### Title: Plot a PST
### Aliases: plot,PSTf,ANY-method plot,PSTr,ANY-method
### Keywords: methods ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)
plot(S1)
plot(S1, horiz=TRUE)
plot(S1, nodePar=list(node.type="path", lab.type="prob", lab.pos=1, lab.offset=2, lab.cex=0.7), edgePar=list(type="triangle"), withlegend=FALSE)



cleanEx()
nameEx("ppplot")
### * ppplot

flush(stderr()); flush(stdout())

### Name: ppplot
### Title: Plotting a branch of a PST
### Aliases: ppplot ppplot,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1.seq <- seqdef(s1)
S1 <- pstree(s1.seq, L=5)
ppplot(S1, "a-a-b-b-a")



cleanEx()
nameEx("pqplot")
### * pqplot

flush(stderr()); flush(stdout())

### Name: pqplot
### Title: Prediction quality plot
### Aliases: pqplot pqplot,PSTf,stslist-method
### Keywords: methods ~~ other possible keyword(s) ~~

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)

z <- seqdef("a-b-a-a-b")
pqplot(S1, z)
pqplot(S1, z, measure="logloss", plotseq=TRUE)



cleanEx()
nameEx("predict")
### * predict

flush(stderr()); flush(stdout())

### Name: predict
### Title: Compute the probability of categorical sequences using a
###   Probabilistic Suffix Tree
### Aliases: predict predict,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)
predict(S1, s1, decomp=TRUE)
predict(S1, s1)



cleanEx()
nameEx("prune")
### * prune

flush(stderr()); flush(stdout())

### Name: prune
### Title: Prune a PST
### Aliases: prune prune,PSTf-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1.seq <- seqdef(s1)
S1 <- pstree(s1.seq, L=3, nmin=2, ymin=0.001)

## --
S1.p1 <- prune(S1, gain="G1", C=1.20, delete=FALSE)
summary(S1.p1)
plot(S1.p1)

## --
C95 <- qchisq(0.95,1)/2
S1.p2 <- prune(S1, gain="G2", C=C95, delete=FALSE)
plot(S1.p2)



cleanEx()
nameEx("pstree")
### * pstree

flush(stderr()); flush(stdout())

### Name: pstree
### Title: Grow a Probabilistic Suffix Tree (PST)
### Aliases: pstree pstree,stslist-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

## Builds a PST on one single sequence
data(s1)
s1.seq <- seqdef(s1)
s1.seq
S1 <- pstree(s1.seq, L = 3)
print(S1, digits = 3)
S1



cleanEx()
nameEx("query")
### * query

flush(stderr()); flush(stdout())

### Name: query
### Title: Retrieve counts or next symbol probability distribution from a
###   Probabilistic Suffix Tree
### Aliases: query query,PSTf-method round,cprobd-method
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)
## Retrieving from the node labelled 'a-a-a'
query(S1, "a-a-a")

## The node 'a-b-b-a' is not presetnin the tree, and the next symbol
## probability is retrieved from the node labelled 'b-b-a' (the longest
## suffix
query(S1, "a-b-b-a")



cleanEx()
nameEx("s1-data")
### * s1-data

flush(stderr()); flush(stdout())

### Name: s1
### Title: Example sequence data set
### Aliases: s1
### Keywords: datasets

### ** Examples

## Loading the data
data(s1)

## Creating a state sequence object
s1.seq <- seqdef(s1)

## Building and plotting a PST
S1 <- pstree(s1.seq, L = 3)
plot(S1)



### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
