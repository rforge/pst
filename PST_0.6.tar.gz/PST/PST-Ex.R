pkgname <- "PST"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('PST')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("cprob")
### * cprob

flush(stderr()); flush(stdout())

### Name: cprob
### Title: Empirical conditional probability distributions
### Aliases: cprob
### Keywords: ~kwd1 ~kwd2

### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--	or do  help(data=index)  for the standard data sets.

## The function is currently defined as
structure(function (object, L, ...) 
standardGeneric("cprob"), generic = structure("cprob", package = "PST"), package = "PST", group = list(), valueClass = character(0), signature = c("object", 
"L"), default = `NULL`, skeleton = function (object, L, ...) 
stop("invalid call in method dispatch to \"cprob\" (no default method)", 
    domain = NA)(object, L, ...), class = structure("standardGeneric", package = "methods"))



cleanEx()
nameEx("generate")
### * generate

flush(stderr()); flush(stdout())

### Name: generate
### Title: Generate sequences using a PST
### Aliases: generate
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1.seq <- seqdef(s1)
S1 <- pstree(s1.seq, L=3)
generate(S1, n=10, l=10, method="prob")
## First state is generated with p(a)=0.9 and p(b)=0.1
generate(S1, n=10, l=10, method="prob", p1=c(0.9, 0.1))



cleanEx()
nameEx("logLik")
### * logLik

flush(stderr()); flush(stdout())

### Name: logLik
### Title: Log Likelihood of a PST
### Aliases: logLik
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1.seq <- seqdef(s1)
S1 <- pstree(s1.seq, L=3)
logLik(S1)	



cleanEx()
nameEx("predict")
### * predict

flush(stderr()); flush(stdout())

### Name: predict
### Title: Compute the probability of categorical sequences using a
###   Probabilistic Suffix Tree
### Aliases: predict
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)
predict(S1, s1, decomp=TRUE)
predict(S1, s1)



cleanEx()
nameEx("pstree")
### * pstree

flush(stderr()); flush(stdout())

### Name: pstree
### Title: Grow a Probabilistic Suffix Tree (PST)
### Aliases: pstree
### Keywords: ~kwd1 ~kwd2

### ** Examples

## Builds a PST on one single sequence
data(s1)
s1 <- seqdef(s1)
s1
S1 <- pstree(s1, L = 3)
print(S1, digits = 3)
S1



cleanEx()
nameEx("query")
### * query

flush(stderr()); flush(stdout())

### Name: query
### Title: Retrieve counts or next symbol probability distribution from a
###   node in a Probabilistic Suffix Tree
### Aliases: query
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(s1)
s1 <- seqdef(s1)
S1 <- pstree(s1, L=3)
## Retrieving from the node labelled 'a-a-a'
query(S1, "a-a-a")

## The node 'a-b-b-a' is not presetnin the tree, and the next symbol
## probability is retrieved from the node labelled 'b-b-a' (the longest
## suffix
query(S1, "a-b-b-a")



### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
