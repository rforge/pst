## Probability distribution of a node and its parents
## and illustration of the pruning process 

setMethod("ppplot", signature="PSTf", 
	def=function(object, path, state, gain, C,  cex.plot=1, seqscale=0.3, node.type="circle", pscale=seqscale/2, 
		pruned.col="red", div.col="green", ...) {

		A <- object@alphabet
		cpal <- c(object@cpal)

		if (has.cdata(object)) {
			c.A <-  alphabet(object@cdata)
			c.cpal <- cpal(object@cdata)
		} else { 
			c.A <- A 
			c.cpal <- cpal
		}
	
		nbstate <- length(A)
		oolist <- list(...)

		if (length(path)==1) { path <- seqdecomp(path) }

		sl <- length(path)

		## Retrieving probabilities
		prob <- matrix(nrow=nbstate, ncol=sl+1)
		N <- matrix(nrow=1, ncol=sl+1)

		node <- query(object, "e", output="all")
		prob[,(sl+1)] <- as.numeric(node@prob)
		N[,sl+1] <- node@n
	
		lsuff <- lsuffix(object, path)
		lsp <- sl-length(lsuff)+1	

		for (j in lsp:sl) {
			node <- query(object, paste(path[j:sl], collapse="-"), output="all")
			prob[,j] <- as.numeric(node@prob)
			N[,j] <- node@n

		}

		## Plotting path
		barw <- 1
		gsep <- 0.1
		ppsep <- pscale/4
		poff <- 0

		nC <- if (!missing(C)) { length(C) } else { 0 }

		plot(NULL, 
			xlim=c(1-seqscale, sl+2),
			ylim=c(0,(seqscale+gsep+1+(nC*(pscale+ppsep))+ ((nC>0)*gsep))),
			axes=FALSE,
			xlab="L (memory)", ylab="",
			...)

		## Tag as div 
		if (!missing(C)) {
			div <- matrix(nrow=nC, ncol=sl)
			pruned <- matrix(nrow=nC, ncol=sl)

			for (j in lsp:sl) {
				idpar <- 1
				if (gain=="G1") {
					for (i in 1:nC) { 
						div[idpar, j] <- G1(prob[,j], prob[,(j+1)], C=r[i])
						idpar <- idpar+1
					}
				} else if (gain=="G2") {
					for (i in 1:nC) { 
						div[idpar, j] <- G2(prob[,j], prob[,(j+1)], C=C[i], N=N[,j])
						idpar <- idpar+1
					}
				}
			}

			pruned[,lsp] <- !div[,lsp]
			for (j in (lsp+1):sl) {
				for (pp in 1:nC) {		
					pruned[pp, j] <- !div[pp, j] & pruned[pp, j-1]
				}
			}

			ppar.lab.pos <- NULL
			poff <- poff+(pscale/2)

			for (pp in 1:nC) {
				segments(1, poff, sl+1, poff, col="grey", lwd=3)
	
				for (i in 1:sl) {
					pcol <- if (pruned[pp, i]) {pruned.col} else if ( div[pp,i] ) {div.col} else {"grey"}
					if (node.type=="rectangle") {
						rect(i-seqscale, poff, i+seqscale, poff+pscale, 
							col=pcol)
					} else {
						symbols(x=i, y=poff, circles=pscale, bg=pcol, add=TRUE, inches=FALSE)
					}
				}
	
				symbols(x=sl+1, y=poff,	circles=pscale, bg="grey", add=TRUE, inches=FALSE)

				ppar.lab.pos <- c(ppar.lab.pos, poff)
				poff <- poff+pscale+ppsep
			}

			ppar.lab <- paste("C", 1:nC, sep="")

			axis(2, at=ppar.lab.pos, 
				labels=ppar.lab, 
				## las=2, 
				cex.axis=cex.plot)
		}

		## Plotting path and next symbol probability distributions
		poff <- poff+(seqscale/2)
		prob.yBottom <- poff+(seqscale/2)+gsep
	
		segments(1, poff, sl+1, poff, col="grey", lwd=3)

		for (i in 1:sl) {
			segments(i, poff, i, poff+(seqscale/2)+gsep, col="grey", lwd=3)
	
			symbols(x=i, y=poff, circles=seqscale, bg=c.cpal[which(path[i]==c.A)], add=TRUE, inches=FALSE)
			text(x=i, y=poff, labels=path[i])
			plotProb(i-seqscale, prob.yBottom , i+seqscale, prob.yBottom+1, prob=t(prob[,i]), state, cpal=cpal)
		}

		## ROOT NODE
		segments(sl+1, poff, sl+1, poff+(seqscale/2)+gsep, col="grey", lwd=3)

		symbols(sl+1, y=poff, circles=seqscale, bg="grey", add=TRUE, inches=FALSE)
		text(x=sl+1, y=poff, labels="e")

		## Plotting next symbol probability distributions
		plotProb((sl+1)-seqscale, prob.yBottom, (sl+1)+seqscale, prob.yBottom+1, t(prob[,sl+1]), state, cpal)

		axis(1, at=(1:(sl+1)), labels=sl:0, pos=-0.04)

		plabpos <- seq(from=prob.yBottom, to=(prob.yBottom+1), by=0.2)
		plab <- plabpos-prob.yBottom

		axis(2, at=plabpos, 
			labels=plab, 
			## las=2, 
			cex.axis=cex.plot)
	}
)

