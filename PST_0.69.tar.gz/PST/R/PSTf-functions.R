
node.list <- function(x, pruned=FALSE) {

	plist <- lapply(x, names)
	plist
}

pruned.nodes <- function(x) {
	pruned.list <- lapply(x, is.pruned)
	pruned.list <- unlist(pruned.list)
	return(pruned.list)
}

leaves.list <- function(x) {
	res <- lapply(x, function(x) { all(x@leaf) } )
	res <- unlist(res)
	return(res)
}


leaves.count <- function(x) {
	res <- lapply(x, function(x) { sum(x@leaf) } )
	res <- unlist(res)
	return(res)
}


nodes.count <- function(x) {
	res <- lapply(x, function(x) { sum(!x@leaf) } )
	res <- unlist(res)
	return(res)
}

## list of leaves
leaves <- function(x) {
	res <- NULL
	for (i in 1:length(x)) {
		nodes.names <- node.list(x[[i]]) 
		tmp <- lapply(x[[i]], function(x) { x@leaf } )
		tmp <- unlist(tmp)
		res <- c(res, nodes.names[tmp])
	}
	return(res)
}


